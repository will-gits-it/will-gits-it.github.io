"""Merge the LoRA adapter into the base weights and (optionally) push to the Hugging Face Hub.

A merged checkpoint can be served by vLLM like any other model, with no
adapter overhead at inference time.
"""
import argparse
import os

import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

from common import native_bf16

CARD = """---
base_model: {base}
library_name: transformers
tags: [text-to-sql, lora, qwen2]
---
# {repo}

{base} fine-tuned with LoRA for text-to-SQL on `b-mc2/sql-create-context`.
Built as part of an LLM fine-tuning, GKE serving, and accelerator benchmarking project.
"""


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--base", default="Qwen/Qwen2.5-1.5B-Instruct")
    p.add_argument("--adapter", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--push", default=None, help="HF repo id, e.g. yourname/qwen2.5-1.5b-sql")
    p.add_argument("--private", action="store_true")
    args = p.parse_args()

    dtype = torch.bfloat16 if native_bf16() else torch.float16
    model = AutoModelForCausalLM.from_pretrained(args.base, torch_dtype=dtype)
    model = PeftModel.from_pretrained(model, args.adapter).merge_and_unload()
    tok = AutoTokenizer.from_pretrained(args.adapter)

    os.makedirs(args.out, exist_ok=True)
    model.save_pretrained(args.out, safe_serialization=True)
    tok.save_pretrained(args.out)
    print(f"merged model saved to {args.out}")

    if args.push:
        from huggingface_hub import HfApi
        with open(os.path.join(args.out, "README.md"), "w") as f:
            f.write(CARD.format(base=args.base, repo=args.push))
        api = HfApi()
        api.create_repo(args.push, private=args.private, exist_ok=True)
        api.upload_folder(folder_path=args.out, repo_id=args.push, commit_message="Merged LoRA fine-tune")
        print(f"pushed to https://huggingface.co/{args.push}")


if __name__ == "__main__":
    main()
