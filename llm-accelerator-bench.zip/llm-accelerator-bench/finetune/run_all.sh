#!/usr/bin/env bash
# Full pipeline: train -> eval base -> eval fine-tuned -> merge -> push -> upload results.
# Runs the same way in the GKE training Job, on a GPU VM, or in Colab.
#
# Env vars:
#   BASE_MODEL  default Qwen/Qwen2.5-1.5B-Instruct
#   OUT_DIR     default /tmp/out
#   HF_REPO     e.g. yourname/qwen2.5-1.5b-sql (needs HF_TOKEN with write access)
#   GCS_URI     e.g. gs://your-bucket/run1 (optional)
#   EXTRA_TRAIN_ARGS  extra flags for train_lora.py, e.g. "--batch-size 4 --grad-accum 2" on a T4
set -euo pipefail
cd "$(dirname "$0")"

BASE_MODEL="${BASE_MODEL:-Qwen/Qwen2.5-1.5B-Instruct}"
OUT_DIR="${OUT_DIR:-/tmp/out}"
mkdir -p "$OUT_DIR"

echo "== installing deps"
pip install -q -r requirements.txt

echo "== [1/5] LoRA fine-tune"
python train_lora.py --model "$BASE_MODEL" --out "$OUT_DIR" ${EXTRA_TRAIN_ARGS:-}

echo "== [2/5] eval: base model"
python evaluate.py --base "$BASE_MODEL" --out "$OUT_DIR/eval_base.json"

echo "== [3/5] eval: fine-tuned"
python evaluate.py --base "$BASE_MODEL" --adapter "$OUT_DIR/adapter" --out "$OUT_DIR/eval_finetuned.json"

echo "== [4/5] merge (+ push to HF Hub if HF_REPO is set)"
python merge_and_push.py --base "$BASE_MODEL" --adapter "$OUT_DIR/adapter" \
  --out "$OUT_DIR/merged" ${HF_REPO:+--push "$HF_REPO"}

echo "== [5/5] upload results"
if [ -n "${GCS_URI:-}" ]; then
  python gcs_upload.py "$OUT_DIR" "$GCS_URI"
else
  echo "GCS_URI not set; results are in $OUT_DIR"
fi

echo "== summary"
python - "$OUT_DIR" <<'EOF'
import json, sys, os
d = sys.argv[1]
m = json.load(open(os.path.join(d, "train_metrics.json")))
b = json.load(open(os.path.join(d, "eval_base.json")))
f = json.load(open(os.path.join(d, "eval_finetuned.json")))
print(f"device={m['device']} train={m['wall_seconds']}s tok/s~{m['approx_tokens_per_second']} peak_mem={m['peak_gpu_mem_gb']}GB")
print(f"exact match: base={b['exact_match']:.1%} -> fine-tuned={f['exact_match']:.1%}")
EOF
