"""Exact-match accuracy on the held-out split, for the base model or base + LoRA adapter.

Also records naive Hugging Face `generate()` throughput, which makes a useful
contrast with the vLLM serving numbers later on.
"""
import argparse
import time

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from common import DEFAULT_DATASET, build_messages, load_splits, native_bf16, normalize_sql, write_json


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--base", default="Qwen/Qwen2.5-1.5B-Instruct")
    p.add_argument("--adapter", default=None)
    p.add_argument("--dataset", default=DEFAULT_DATASET)
    p.add_argument("--n", type=int, default=200)
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--max-new-tokens", type=int, default=160)
    p.add_argument("--out", required=True)
    return p.parse_args()


def main():
    args = parse_args()
    cuda = torch.cuda.is_available()
    dtype = (torch.bfloat16 if native_bf16() else torch.float16) if cuda else torch.float32
    device = "cuda" if cuda else "cpu"

    tok = AutoTokenizer.from_pretrained(args.adapter or args.base)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "left"  # left-pad for batched generation

    model = AutoModelForCausalLM.from_pretrained(args.base, torch_dtype=dtype).to(device)
    if args.adapter:
        from peft import PeftModel
        model = PeftModel.from_pretrained(model, args.adapter)
    model.eval()

    _, test = load_splits(0, args.n, args.dataset)
    rows = list(test)
    correct, gen_tokens, gen_time, samples = 0, 0, 0.0, []

    for i in range(0, len(rows), args.batch_size):
        batch = rows[i:i + args.batch_size]
        prompts = [
            tok.apply_chat_template(build_messages(r["context"], r["question"]),
                                    add_generation_prompt=True, tokenize=False)
            for r in batch
        ]
        enc = tok(prompts, return_tensors="pt", padding=True, add_special_tokens=False).to(device)
        if cuda:
            torch.cuda.synchronize()
        t0 = time.time()
        with torch.no_grad():
            out = model.generate(
                **enc, max_new_tokens=args.max_new_tokens, do_sample=False,
                temperature=None, top_p=None, top_k=None, pad_token_id=tok.pad_token_id,
            )
        if cuda:
            torch.cuda.synchronize()
        gen_time += time.time() - t0
        new = out[:, enc["input_ids"].shape[1]:]
        gen_tokens += int((new != tok.pad_token_id).sum())
        preds = tok.batch_decode(new, skip_special_tokens=True)
        for r, pred in zip(batch, preds):
            ok = normalize_sql(pred) == normalize_sql(r["answer"])
            correct += ok
            if len(samples) < 25:
                samples.append({"question": r["question"], "gold": r["answer"],
                                "pred": pred.strip(), "match": ok})
        print(f"{min(i + args.batch_size, len(rows))}/{len(rows)}  running acc={correct / (i + len(batch)):.3f}")

    result = {
        "model": args.base,
        "adapter": args.adapter,
        "n": len(rows),
        "exact_match": round(correct / max(len(rows), 1), 4),
        "hf_generate_tokens_per_second": round(gen_tokens / gen_time, 1) if gen_time else None,
        "batch_size": args.batch_size,
        "samples": samples,
    }
    write_json(args.out, result)
    print(f"exact_match={result['exact_match']}  hf_generate_tok/s={result['hf_generate_tokens_per_second']}")


if __name__ == "__main__":
    main()
