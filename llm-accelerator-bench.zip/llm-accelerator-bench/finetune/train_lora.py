"""LoRA fine-tune a small open LLM for text-to-SQL, with PyTorch profiling.

Outputs (under --out):
  adapter/           LoRA adapter weights + tokenizer
  profiler/          Chrome/Perfetto trace of a few training steps + top_ops.txt
  train_metrics.json runtime, tokens/sec, peak GPU memory, loss curve

Runs on an NVIDIA L4/T4/A100 (bf16 when supported, fp16 otherwise) or CPU
(for smoke tests only).
"""
import argparse
import os
import time

import torch
from peft import LoraConfig, get_peft_model
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    Trainer,
    TrainerCallback,
    TrainingArguments,
)

from common import DEFAULT_DATASET, build_messages, load_splits, native_bf16, write_json

LORA_TARGETS = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="Qwen/Qwen2.5-1.5B-Instruct")
    p.add_argument("--dataset", default=DEFAULT_DATASET)
    p.add_argument("--out", default="out")
    p.add_argument("--n-train", type=int, default=4000)
    p.add_argument("--epochs", type=float, default=1.0)
    p.add_argument("--lr", type=float, default=2e-4)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--grad-accum", type=int, default=1)
    p.add_argument("--max-len", type=int, default=512)
    p.add_argument("--lora-r", type=int, default=16)
    p.add_argument("--lora-alpha", type=int, default=32)
    p.add_argument("--profile-steps", type=int, default=3, help="0 disables profiling")
    p.add_argument("--max-steps", type=int, default=-1, help="for smoke tests")
    return p.parse_args()


def pick_dtype():
    if torch.cuda.is_available():
        return torch.bfloat16 if native_bf16() else torch.float16
    return torch.float32


def make_tokenize_fn(tok, max_len):
    def tokenize(ex):
        msgs = build_messages(ex["context"], ex["question"])
        prompt = tok.apply_chat_template(msgs, add_generation_prompt=True, tokenize=False)
        full = tok.apply_chat_template(
            msgs + [{"role": "assistant", "content": ex["answer"]}], tokenize=False
        )
        if full.startswith(prompt):
            completion = full[len(prompt):]
        else:  # unusual template: fall back to answer + EOS
            completion = ex["answer"] + (tok.eos_token or "")
        p_ids = tok(prompt, add_special_tokens=False)["input_ids"]
        c_ids = tok(completion, add_special_tokens=False)["input_ids"]
        ids = p_ids + c_ids
        # Loss is computed only on the SQL answer, not on the prompt.
        labels = [-100] * len(p_ids) + c_ids
        return {"input_ids": ids, "labels": labels, "length": len(ids)}

    return tokenize


class PadCollator:
    def __init__(self, pad_id):
        self.pad_id = pad_id

    def __call__(self, batch):
        n = max(len(b["input_ids"]) for b in batch)
        ids, labels, mask = [], [], []
        for b in batch:
            pad = n - len(b["input_ids"])
            ids.append(b["input_ids"] + [self.pad_id] * pad)
            labels.append(b["labels"] + [-100] * pad)
            mask.append([1] * len(b["input_ids"]) + [0] * pad)
        return {
            "input_ids": torch.tensor(ids),
            "labels": torch.tensor(labels),
            "attention_mask": torch.tensor(mask),
        }


class ProfilerCallback(TrainerCallback):
    """Profiles a handful of steady-state steps (skips the first few warm-up steps)."""

    WAIT, WARMUP = 5, 2

    def __init__(self, out_dir, active_steps):
        self.out_dir, self.active = out_dir, active_steps
        self.prof, self.steps = None, 0

    def on_train_begin(self, args, state, control, **kw):
        acts = [torch.profiler.ProfilerActivity.CPU]
        if torch.cuda.is_available():
            acts.append(torch.profiler.ProfilerActivity.CUDA)
        os.makedirs(self.out_dir, exist_ok=True)
        self.prof = torch.profiler.profile(
            activities=acts,
            schedule=torch.profiler.schedule(
                wait=self.WAIT, warmup=self.WARMUP, active=self.active, repeat=1
            ),
            on_trace_ready=torch.profiler.tensorboard_trace_handler(self.out_dir),
            record_shapes=True,
            profile_memory=True,
        )
        self.prof.__enter__()

    def on_step_end(self, args, state, control, **kw):
        if self.prof is None:
            return
        self.prof.step()
        self.steps += 1
        if self.steps >= self.WAIT + self.WARMUP + self.active + 1:
            self._finish()

    def on_train_end(self, args, state, control, **kw):
        if self.prof is not None:
            self._finish()

    def _finish(self):
        prof, self.prof = self.prof, None
        prof.__exit__(None, None, None)
        table = None
        for key in ("self_cuda_time_total", "self_device_time_total", "self_cpu_time_total"):
            try:
                table = prof.key_averages().table(sort_by=key, row_limit=25)
                break
            except Exception:
                continue
        if table:
            with open(os.path.join(self.out_dir, "top_ops.txt"), "w") as f:
                f.write(table)
            print(table)


def main():
    args = parse_args()
    os.makedirs(args.out, exist_ok=True)
    dtype = pick_dtype()
    device = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu"
    print(f"device={device} dtype={dtype}")

    tok = AutoTokenizer.from_pretrained(args.model)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    tok.padding_side = "right"

    train_ds, _ = load_splits(args.n_train, 0, args.dataset)
    train_ds = train_ds.map(make_tokenize_fn(tok, args.max_len), remove_columns=train_ds.column_names)
    before = len(train_ds)
    train_ds = train_ds.filter(lambda ex: ex["length"] <= args.max_len)
    print(f"train examples: {len(train_ds)} (dropped {before - len(train_ds)} longer than {args.max_len})")

    model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype=dtype, attn_implementation="sdpa")
    model.config.use_cache = False
    model = get_peft_model(model, LoraConfig(
        r=args.lora_r, lora_alpha=args.lora_alpha, lora_dropout=0.05,
        target_modules=LORA_TARGETS, task_type="CAUSAL_LM",
    ))
    # Keep the small set of trainable LoRA weights in fp32 for stable mixed precision.
    for p in model.parameters():
        if p.requires_grad:
            p.data = p.data.float()
    model.print_trainable_parameters()

    targs = TrainingArguments(
        output_dir=os.path.join(args.out, "checkpoints"),
        per_device_train_batch_size=args.batch_size,
        gradient_accumulation_steps=args.grad_accum,
        num_train_epochs=args.epochs,
        max_steps=args.max_steps,
        learning_rate=args.lr,
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
        logging_steps=10,
        save_strategy="no",
        bf16=dtype == torch.bfloat16,
        fp16=dtype == torch.float16,
        report_to="none",
        dataloader_num_workers=2 if torch.cuda.is_available() else 0,
        remove_unused_columns=False,
        seed=42,
    )
    callbacks = []
    if args.profile_steps > 0:
        callbacks.append(ProfilerCallback(os.path.join(args.out, "profiler"), args.profile_steps))

    trainer = Trainer(
        model=model, args=targs, train_dataset=train_ds,
        data_collator=PadCollator(tok.pad_token_id), callbacks=callbacks,
    )
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    t0 = time.time()
    result = trainer.train()
    wall = time.time() - t0

    steps = trainer.state.global_step
    examples_seen = steps * args.batch_size * args.grad_accum
    avg_len = sum(train_ds["length"]) / max(len(train_ds), 1)
    metrics = {
        "model": args.model,
        "device": device,
        "dtype": str(dtype).replace("torch.", ""),
        "train_examples": len(train_ds),
        "steps": steps,
        "wall_seconds": round(wall, 1),
        "train_samples_per_second": round(examples_seen / wall, 2),
        "approx_tokens_per_second": round(examples_seen * avg_len / wall, 1),
        "final_train_loss": round(result.training_loss, 4),
        "peak_gpu_mem_gb": round(torch.cuda.max_memory_allocated() / 1e9, 2) if torch.cuda.is_available() else None,
        "lora": {"r": args.lora_r, "alpha": args.lora_alpha, "targets": LORA_TARGETS},
        "loss_curve": [
            {"step": h["step"], "loss": h["loss"]} for h in trainer.state.log_history if "loss" in h
        ],
    }
    write_json(os.path.join(args.out, "train_metrics.json"), metrics)
    print({k: v for k, v in metrics.items() if k != "loss_curve"})

    model.save_pretrained(os.path.join(args.out, "adapter"))
    tok.save_pretrained(os.path.join(args.out, "adapter"))


if __name__ == "__main__":
    main()
