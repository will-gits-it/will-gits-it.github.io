"""Upload run outputs (metrics, eval results, profiler traces, adapter) to Cloud Storage.

Skips the merged full-weight checkpoint, which lives on the Hugging Face Hub.
Authenticates with Workload Identity when running on GKE.
"""
import os
import sys

from google.cloud import storage


def main(local_dir: str, gcs_uri: str):
    assert gcs_uri.startswith("gs://"), "GCS_URI must look like gs://bucket/prefix"
    bucket_name, _, prefix = gcs_uri[5:].partition("/")
    bucket = storage.Client().bucket(bucket_name)
    n = 0
    for root, dirs, files in os.walk(local_dir):
        dirs[:] = [d for d in dirs if d not in ("merged", "checkpoints")]
        for name in files:
            path = os.path.join(root, name)
            rel = os.path.relpath(path, local_dir)
            bucket.blob(f"{prefix.rstrip('/')}/{rel}" if prefix else rel).upload_from_filename(path)
            n += 1
    print(f"uploaded {n} files to {gcs_uri}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
