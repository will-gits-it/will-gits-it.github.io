"""Shared helpers: prompt format, dataset splits, and SQL normalization.

The same prompt format is used for training, evaluation, and the serving
benchmark, so base-vs-fine-tuned comparisons are apples to apples.
"""
import json
import re

DEFAULT_DATASET = "b-mc2/sql-create-context"  # ~78k (question, schema, SQL) triples
TEST_POOL = 500  # first 500 shuffled rows are held out and never trained on
SEED = 42

INSTRUCTION = (
    "You are a text-to-SQL assistant. Given the table schema and a question, "
    "reply with a single SQL query and nothing else."
)


def build_messages(context: str, question: str):
    # The instruction lives in the user turn (no system role) so the same code
    # works with chat templates that reject system messages (e.g. Gemma).
    return [{
        "role": "user",
        "content": f"{INSTRUCTION}\n\nSchema:\n{context}\n\nQuestion: {question}",
    }]


def load_splits(n_train: int, n_test: int, dataset: str = DEFAULT_DATASET):
    """Deterministic split: rows [0, TEST_POOL) are test, the rest are train."""
    from datasets import load_dataset

    if dataset.endswith(".jsonl") or dataset.endswith(".json"):
        ds = load_dataset("json", data_files=dataset, split="train")
    else:
        ds = load_dataset(dataset, split="train")
    ds = ds.shuffle(seed=SEED)
    pool = min(TEST_POOL, len(ds) // 5)
    test = ds.select(range(min(n_test, pool)))
    train = ds.select(range(pool, min(pool + n_train, len(ds))))
    return train, test


_FENCE = re.compile(r"^```(?:sql)?\s*|\s*```$", re.IGNORECASE)


def normalize_sql(s: str) -> str:
    """Loose normalization for exact-match scoring.

    Strips code fences, trailing semicolons, whitespace differences, quote
    style and case. It is deliberately simple; execution-based accuracy would
    be stricter and is listed as future work in the README.
    """
    s = _FENCE.sub("", s.strip()).strip()
    s = s.rstrip(";").strip()
    s = s.replace('"', "'")
    s = re.sub(r"\s+", " ", s)
    return s.lower()


def native_bf16() -> bool:
    """True only on GPUs with hardware bf16 (compute capability 8.0+: A100, L4, H100...).

    torch.cuda.is_bf16_supported() also returns True on older GPUs like the T4, where
    bf16 is emulated: matmuls then run as fp32 SGEMM without tensor cores (found via profiler).
    """
    import torch
    return torch.cuda.is_available() and torch.cuda.get_device_capability(0)[0] >= 8


def write_json(path: str, obj) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
