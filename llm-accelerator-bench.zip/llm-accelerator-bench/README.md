# Fine-tune, serve, and price an LLM on GKE accelerators

An end-to-end project that takes a small open LLM from fine-tuning to a priced
production recommendation, using GPUs on Google Kubernetes Engine:

1. **Fine-tune** Qwen2.5-1.5B-Instruct with LoRA for text-to-SQL, as a Kubernetes Job on GKE (or in Colab on a T4)
2. **Profile** the training loop with the PyTorch profiler to see where GPU time goes
3. **Evaluate** base vs fine-tuned accuracy on a held-out set
4. **Serve** the merged model with vLLM on GKE Autopilot, on both L4 and T4 GPUs
5. **Benchmark** throughput and latency under load, from inside the cluster
6. **Recommend** the cheapest accelerator that meets a latency target, in cost per 1M tokens

The goal is to answer a question customers ask about AI infrastructure every day:
*"Given my model and my latency target, what hardware should I run it on, and what will it cost?"*

## Results

### Fine-tuning (done: Colab, 1× NVIDIA T4)

![Training loss and accuracy](results/finetune-t4/finetune.png)

| | Base model | Fine-tuned (LoRA) |
|---|---:|---:|
| Exact-match accuracy, 200 held-out questions | **46.0%** | **70.0%** |

| Training run | |
|---|---:|
| Train examples / optimizer steps | 4,000 / 500 (batch 4 × grad-accum 2) |
| Wall time | 32.7 min |
| Throughput | ~249 tokens/s, 2.0 examples/s |
| Peak GPU memory | 9.9 GB of 16 GB |
| Trainable parameters | ~18.5M, about 1.2% of the model (LoRA r=16 on all attention + MLP projections) |
| Final training loss | 0.054 (from 0.20 at step 10) |

**What changed in the model's answers.** The base model often understood the question but
wrapped answers in code fences, added conditions nobody asked for, or used a different
quoting style. After fine-tuning, it answers with a single query in the dataset's style; the
remaining errors are mostly real reasoning mistakes (wrong aggregate, wrong join direction).
Examples are in `results/finetune-t4/eval_*.json`.

**What the profiler showed.** Matrix multiplications took **87% of GPU time**, and they ran as
`magma_sgemmEx_kernel<float, __nv_bfloat16>`: fp32 SGEMM on bf16 inputs, *without tensor
cores*. The T4 (Turing, compute capability 7.5) has no hardware bf16, but
`torch.cuda.is_bf16_supported()` returns True on it, so the script picked an emulated format.
The fix (now in `finetune/common.py: native_bf16()`) uses bf16 only on compute capability 8.0+
(A100, L4, H100) and fp16 otherwise, which runs on the T4's tensor cores. The CPU side was
mostly blocked on a full GPU command queue, confirming the run was GPU-bound rather than
waiting on data loading. Peak memory left ~6 GB free, so a larger per-device batch is the
next lever. Raw table: `results/finetune-t4/top_ops.txt`.

> Next run: rerun with the fp16 fix and compare tokens/s against the 249 above.

### Serving and cost (pending GPU quota on GKE)

Steps 3–4 of the runbook produce `results/summary.md` and `results/charts.png`: throughput,
p95 time to first token, and cost per 1M output tokens on L4 vs T4, plus a recommendation
at a latency target.

## Architecture

```
                 GKE Autopilot (us-central1)
 ┌──────────────────────────────────────────────────────────────────┐
 │  Job: finetune (1× L4)                                           │
 │   pytorch image + ConfigMap code ── LoRA train ── eval ── merge  │
 │        │                                            │            │
 │        ▼ Workload Identity (no keys)                ▼            │
 │   Cloud Storage: metrics, profiler traces,     Hugging Face Hub: │
 │   eval results, adapter                        merged model      │
 │                                                     │            │
 │  Deployment: vllm-l4 (1× L4) ◄──────────────────────┤            │
 │  Deployment: vllm-t4 (1× T4) ◄──────────────────────┘            │
 │        ▲                                                         │
 │  Job: bench-l4 / bench-t4 (CPU) ── streaming load test in-cluster│
 └──────────────────────────────────────────────────────────────────┘
```

Design choices worth noting:
- **Autopilot** provisions GPU nodes on demand from a `nodeSelector`, so there are no node pools to size, and you stop paying when the pods are gone.
- **Workload Identity** binds the Kubernetes service account directly to a bucket role. No service-account keys anywhere.
- **Same vLLM settings on both GPUs** (fp16, same max length and memory fraction), so the comparison isolates the hardware.
- **Fixed output length** (`ignore_eos`) in the load test, so every request generates the same number of tokens and runs are directly comparable.
- **Load generated in-cluster**, so `kubectl port-forward` and internet latency don't distort the numbers.
- **Loss on answer tokens only**: the prompt is masked out of the labels, so the model learns to write SQL, not to repeat schemas.

## Repo layout

```
finetune/  train_lora.py (LoRA + profiler), evaluate.py, merge_and_push.py, run_all.sh
bench/     benchmark.py (stdlib-only load generator), analyze.py (cost + charts), prompts.jsonl
k8s/       train-job.yaml, vllm.yaml, bench-job.yaml
infra/     env.sh, setup.sh, train.sh, serve.sh, bench.sh, teardown.sh
results/   benchmark JSON, summary.md, charts.png
```

## Runbook

Everything runs from **Cloud Shell**, which already has `gcloud`, `kubectl`, and `envsubst`.

### 0. Prerequisites
- A GCP project with billing on a **paid** account (free-trial accounts can't use GPUs).
- GPU quota in `us-central1`: at least 1 `NVIDIA_L4_GPUS`, 1 `NVIDIA_T4_GPUS`, and `GPUS_ALL_REGIONS` ≥ 2.
- A Hugging Face account and a **write** token.

### 1. Setup (~10 min)
```bash
git clone https://github.com/<you>/llm-accelerator-bench && cd llm-accelerator-bench
nano infra/env.sh                 # set PROJECT_ID and HF_USER
source infra/env.sh
export HF_TOKEN=hf_xxx
bash infra/setup.sh
```

### 2. Fine-tune (~35-45 min, mostly unattended)
```bash
bash infra/train.sh
kubectl get pods -l app=finetune -w   # Pending while Autopilot adds a GPU node; that's normal
kubectl logs -f job/finetune
```
When it finishes, the log prints base vs fine-tuned accuracy. Pull the outputs down:
```bash
mkdir -p results/train && gcloud storage cp -r "$GCS_URI/*" results/train/
cat results/train/train_metrics.json results/train/profiler/top_ops.txt
```
The `.pt.trace.json` file in `results/train/profiler/` opens in [Perfetto](https://ui.perfetto.dev).

### 3. Serve on both GPUs (~10 min, run both at once)
```bash
bash infra/serve.sh l4 & bash infra/serve.sh t4 & wait
kubectl port-forward svc/vllm-l4 8000:8000 &
curl -s localhost:8000/v1/chat/completions -H 'Content-Type: application/json' -d '{
  "model":"sql-coder","temperature":0,"messages":[{"role":"user","content":
  "You are a text-to-SQL assistant. Given the table schema and a question, reply with a single SQL query and nothing else.\n\nSchema:\nCREATE TABLE orders (id INTEGER, status VARCHAR, total REAL)\n\nQuestion: How many orders are shipped?"}]}'
```

### 4. Benchmark (~10 min per GPU)
`HOURLY_USD` is what one serving replica costs per hour. On Autopilot that's the GPU plus the
4 vCPU and 16 GiB the pod requests. Add them up from the
[GKE pricing page](https://cloud.google.com/kubernetes-engine/pricing) (Autopilot, accelerator section) for us-central1.
```bash
HOURLY_USD=<l4 price> bash infra/bench.sh l4
HOURLY_USD=<t4 price> bash infra/bench.sh t4
pip install matplotlib && python bench/analyze.py --slo-ttft-ms 500
```

### 5. Tear down (do not skip)
```bash
bash infra/teardown.sh          # removes GPU pods; idle Autopilot cluster costs very little
bash infra/teardown.sh --all    # deletes the cluster too
```

### No GPU quota yet? Fine-tune in Colab instead
Open a Colab notebook with a T4 runtime, upload the `finetune/` folder, and run:
```python
%env HF_TOKEN=hf_xxx
%env HF_REPO=<you>/qwen2.5-1.5b-sql
%env EXTRA_TRAIN_ARGS=--batch-size 4 --grad-accum 2
!bash finetune/run_all.sh
```
Then continue from step 3 once quota is approved.

## What I'd do next
- **TPUs:** serve the same model on Cloud TPU v5e/v6e with vLLM's TPU backend or JetStream, and add it to the cost comparison.
- **Cloud Storage FUSE** to load weights from a bucket instead of the Hub: faster cold starts and no external dependency.
- **Autoscaling on queue depth** (HPA on vLLM's `num_requests_waiting` metric) instead of CPU.
- **Execution-based accuracy**: run predicted and gold SQL against generated tables instead of string matching.
- **Quantization** (FP8 on L4, AWQ on T4) to see how much cost per token drops, and what accuracy it costs.

## License

MIT. See [LICENSE](LICENSE). Use it however you like.
