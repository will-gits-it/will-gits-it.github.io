"""Load generator for an OpenAI-compatible LLM server (vLLM, TGI, JetStream, ...).

Standard library only, so it runs in a bare python image. For each
concurrency level it sends N streaming chat requests and measures:

  TTFT   time to first token (what a user feels as "responsiveness")
  TPOT   time per output token after the first (streaming speed per user)
  E2E    end-to-end request latency
  tok/s  aggregate output tokens per second (what you pay for)

and, given the replica's hourly price, cost per 1M output tokens.
"""
import argparse
import http.client
import json
import random
import statistics
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse


def pct(values, q):
    if not values:
        return None
    s = sorted(values)
    k = (len(s) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(s) - 1)
    return s[lo] + (s[hi] - s[lo]) * (k - lo)


def load_prompts(path):
    with open(path) as f:
        return [json.loads(line)["messages"] for line in f if line.strip()]


class Client:
    def __init__(self, url, model, max_tokens, fixed_output, timeout):
        u = urlparse(url)
        self.host, self.port = u.hostname, u.port or (443 if u.scheme == "https" else 80)
        self.https = u.scheme == "https"
        self.model, self.max_tokens, self.fixed, self.timeout = model, max_tokens, fixed_output, timeout

    def _conn(self):
        cls = http.client.HTTPSConnection if self.https else http.client.HTTPConnection
        return cls(self.host, self.port, timeout=self.timeout)

    def discover_model(self):
        c = self._conn()
        c.request("GET", "/v1/models")
        data = json.loads(c.getresponse().read())
        return data["data"][0]["id"]

    def request(self, messages):
        body = {
            "model": self.model,
            "messages": messages,
            "max_tokens": self.max_tokens,
            "temperature": 0,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if self.fixed:
            # vLLM extension: keep generating to max_tokens so every request has
            # the same output length and hardware runs are directly comparable.
            body["ignore_eos"] = True
        c = self._conn()
        t0 = time.perf_counter()
        ttft, chunks, usage_tokens = None, 0, None
        try:
            c.request("POST", "/v1/chat/completions", json.dumps(body),
                      {"Content-Type": "application/json"})
            r = c.getresponse()
            if r.status != 200:
                return {"error": f"HTTP {r.status}: {r.read()[:200]!r}"}
            while True:
                line = r.readline()
                if not line:
                    break
                line = line.decode().strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                obj = json.loads(data)
                if obj.get("usage"):
                    usage_tokens = obj["usage"].get("completion_tokens")
                for ch in obj.get("choices") or []:
                    if (ch.get("delta") or {}).get("content"):
                        if ttft is None:
                            ttft = time.perf_counter() - t0
                        chunks += 1
        except Exception as e:  # network errors count as failed requests
            return {"error": repr(e)}
        finally:
            c.close()
        latency = time.perf_counter() - t0
        tokens = usage_tokens or chunks
        if ttft is None or tokens == 0:
            return {"error": "no tokens returned"}
        tpot = (latency - ttft) / (tokens - 1) if tokens > 1 else None
        return {"ttft": ttft, "latency": latency, "tokens": tokens, "tpot": tpot}


def run_level(client, prompts, concurrency, n_requests):
    jobs = [random.choice(prompts) for _ in range(n_requests)]
    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=concurrency) as pool:
        results = list(pool.map(client.request, jobs))
    wall = time.perf_counter() - t0
    ok = [r for r in results if "error" not in r]
    errors = [r["error"] for r in results if "error" in r]
    total_tokens = sum(r["tokens"] for r in ok)
    tpots = [r["tpot"] for r in ok if r["tpot"] is not None]
    return {
        "concurrency": concurrency,
        "requests": n_requests,
        "errors": len(errors),
        "sample_error": errors[0] if errors else None,
        "wall_s": round(wall, 2),
        "requests_per_s": round(len(ok) / wall, 3),
        "output_tokens_per_s": round(total_tokens / wall, 1),
        "ttft_p50_ms": round(pct([r["ttft"] for r in ok], 0.5) * 1000, 1) if ok else None,
        "ttft_p95_ms": round(pct([r["ttft"] for r in ok], 0.95) * 1000, 1) if ok else None,
        "tpot_mean_ms": round(statistics.mean(tpots) * 1000, 2) if tpots else None,
        "e2e_p50_s": round(pct([r["latency"] for r in ok], 0.5), 3) if ok else None,
        "e2e_p95_s": round(pct([r["latency"] for r in ok], 0.95), 3) if ok else None,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--url", required=True, help="e.g. http://vllm-l4:8000")
    p.add_argument("--label", required=True, help="e.g. l4")
    p.add_argument("--model", default=None, help="defaults to the first model the server lists")
    p.add_argument("--prompts", default="prompts.jsonl")
    p.add_argument("--concurrency", default="1,4,8,16,32,64")
    p.add_argument("--requests-per-level", type=int, default=64)
    p.add_argument("--max-tokens", type=int, default=128)
    p.add_argument("--fixed-output", action="store_true")
    p.add_argument("--hourly-usd", type=float, default=0.0,
                   help="price of one serving replica per hour; enables cost per 1M tokens")
    p.add_argument("--timeout", type=float, default=300)
    p.add_argument("--out", default=None, help="write results JSON here")
    p.add_argument("--json-stdout", action="store_true", help="print 'RESULT_JSON {...}' line")
    args = p.parse_args()
    random.seed(0)

    prompts = load_prompts(args.prompts)
    client = Client(args.url, args.model, args.max_tokens, args.fixed_output, args.timeout)
    if client.model is None:
        client.model = client.discover_model()
    print(f"target={args.url} model={client.model} prompts={len(prompts)}", flush=True)

    # Warm-up so first-request effects (CUDA graphs, caches) don't skew level 1.
    for m in prompts[:3]:
        client.request(m)

    levels = []
    print(f"{'conc':>5} {'tok/s':>9} {'req/s':>7} {'TTFTp50':>9} {'TTFTp95':>9} {'TPOT':>7} {'E2Ep95':>8} {'$/1M':>8} err",
          flush=True)
    for c in [int(x) for x in args.concurrency.split(",")]:
        lv = run_level(client, prompts, c, max(args.requests_per_level, c))
        tps = lv["output_tokens_per_s"]
        lv["usd_per_1m_output_tokens"] = (
            round(args.hourly_usd / (tps * 3600) * 1e6, 3) if args.hourly_usd and tps else None
        )
        levels.append(lv)
        cost = f"{lv['usd_per_1m_output_tokens']:.3f}" if lv["usd_per_1m_output_tokens"] else "-"
        print(f"{c:>5} {tps:>9.1f} {lv['requests_per_s']:>7.2f} {lv['ttft_p50_ms']!s:>9} "
              f"{lv['ttft_p95_ms']!s:>9} {lv['tpot_mean_ms']!s:>7} {lv['e2e_p95_s']!s:>8} {cost:>8} "
              f"{lv['errors']}", flush=True)
        if lv["sample_error"]:
            print(f"      sample error: {lv['sample_error']}", flush=True)

    result = {
        "label": args.label,
        "url": args.url,
        "model": client.model,
        "hourly_usd": args.hourly_usd,
        "max_tokens": args.max_tokens,
        "fixed_output": args.fixed_output,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "levels": levels,
    }
    if args.out:
        with open(args.out, "w") as f:
            json.dump(result, f, indent=2)
    if args.json_stdout:
        print("RESULT_JSON " + json.dumps(result), flush=True)


if __name__ == "__main__":
    sys.exit(main())
