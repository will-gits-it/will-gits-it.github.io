"""Turn benchmark results into a cost-to-performance comparison.

Reads results/*.json written by infra/bench.sh and produces:
  results/summary.md      tables + an SLO-based recommendation
  results/charts.png      throughput, p95 TTFT and cost per 1M tokens vs concurrency
  results/summary.json    machine-readable version (used by the project website)

The recommendation answers the question a customer actually asks:
"Given my latency target, which accelerator serves my traffic most cheaply?"
For each GPU it finds the highest-throughput concurrency that still meets the
p95 TTFT target, then compares cost per 1M output tokens at that point.

Usage: python bench/analyze.py --slo-ttft-ms 500
"""
import argparse
import glob
import json
import os

COLORS = {"l4": "#1a73e8", "t4": "#e8710a"}  # distinct under common color-vision deficiencies
FALLBACK = ["#1a73e8", "#e8710a", "#188038", "#a142f4"]


def load(results_dir):
    runs = []
    for path in sorted(glob.glob(os.path.join(results_dir, "*.json"))):
        if os.path.basename(path).startswith("summary"):
            continue
        with open(path) as f:
            data = json.load(f)
        if "levels" in data:
            runs.append(data)
    return runs


def best_under_slo(run, slo_ms):
    ok = [lv for lv in run["levels"]
          if lv["errors"] == 0 and lv["ttft_p95_ms"] is not None and lv["ttft_p95_ms"] <= slo_ms]
    return max(ok, key=lambda lv: lv["output_tokens_per_s"]) if ok else None


def fmt(v, spec):
    return "-" if v is None else format(v, spec)


def write_markdown(runs, slo_ms, path):
    lines = ["# Serving benchmark results", ""]
    for run in runs:
        lines += [
            f"## {run['label'].upper()}  ({run['model']}, ${run['hourly_usd']}/hr, "
            f"{run['max_tokens']} output tokens/request)",
            "",
            "| Concurrency | Output tok/s | Req/s | TTFT p50 (ms) | TTFT p95 (ms) | TPOT (ms) | E2E p95 (s) | $ / 1M output tokens | Errors |",
            "|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
        for lv in run["levels"]:
            lines.append(
                f"| {lv['concurrency']} | {fmt(lv['output_tokens_per_s'], '.0f')} | {fmt(lv['requests_per_s'], '.2f')} "
                f"| {fmt(lv['ttft_p50_ms'], '.0f')} | {fmt(lv['ttft_p95_ms'], '.0f')} | {fmt(lv['tpot_mean_ms'], '.1f')} "
                f"| {fmt(lv['e2e_p95_s'], '.2f')} | {fmt(lv['usd_per_1m_output_tokens'], '.3f')} | {lv['errors']} |"
            )
        lines.append("")

    lines += [f"## Recommendation at a p95 TTFT target of {slo_ms} ms", ""]
    picks = []
    for run in runs:
        b = best_under_slo(run, slo_ms)
        if b is None:
            lines.append(f"- **{run['label'].upper()}**: no tested concurrency met the target.")
        else:
            picks.append((run, b))
            lines.append(
                f"- **{run['label'].upper()}**: best at concurrency {b['concurrency']}: "
                f"{b['output_tokens_per_s']:.0f} tok/s, p95 TTFT {b['ttft_p95_ms']:.0f} ms, "
                f"${fmt(b['usd_per_1m_output_tokens'], '.3f')} per 1M output tokens."
            )
    priced = [(r, b) for r, b in picks if b["usd_per_1m_output_tokens"]]
    if len(priced) >= 2:
        priced.sort(key=lambda rb: rb[1]["usd_per_1m_output_tokens"])
        (w, wb), (l, lb) = priced[0], priced[1]
        ratio = lb["usd_per_1m_output_tokens"] / wb["usd_per_1m_output_tokens"]
        tput = wb["output_tokens_per_s"] / lb["output_tokens_per_s"]
        lines += ["", f"**{w['label'].upper()} is {ratio:.1f}x cheaper per token than {l['label'].upper()}** "
                      f"at this latency target, with {tput:.1f}x the throughput per replica."]
    lines.append("")
    with open(path, "w") as f:
        f.write("\n".join(lines))
    return picks


def plot(runs, slo_ms, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    panels = [
        ("output_tokens_per_s", "Throughput", "output tokens / s"),
        ("ttft_p95_ms", "p95 time to first token", "ms"),
        ("usd_per_1m_output_tokens", "Cost per 1M output tokens", "USD"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))
    for ax, (key, title, unit) in zip(axes, panels):
        for i, run in enumerate(runs):
            pts = [(lv["concurrency"], lv[key]) for lv in run["levels"] if lv[key] is not None]
            if not pts:
                continue
            xs, ys = zip(*pts)
            color = COLORS.get(run["label"].lower(), FALLBACK[i % len(FALLBACK)])
            ax.plot(xs, ys, marker="o", linewidth=2, color=color, label=run["label"].upper())
            ax.annotate(run["label"].upper(), (xs[-1], ys[-1]), textcoords="offset points",
                        xytext=(6, 0), va="center", color=color, fontsize=9, fontweight="bold")
        if key == "ttft_p95_ms":
            ax.axhline(slo_ms, color="#5f6368", linestyle="--", linewidth=1)
            ax.annotate(f"target {slo_ms} ms", (ax.get_xlim()[0], slo_ms), textcoords="offset points",
                        xytext=(4, 4), color="#5f6368", fontsize=8)
        ax.set_xscale("log", base=2)
        ax.set_xlabel("concurrent requests")
        ax.set_ylabel(unit)
        ax.set_title(title, loc="left", fontsize=11, fontweight="bold")
        ax.grid(True, color="#e8eaed", linewidth=0.8)
        ax.spines[["top", "right"]].set_visible(False)
        ax.set_xticks([lv["concurrency"] for lv in runs[0]["levels"]])
        ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    print(f"wrote {path}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--results", default="results")
    p.add_argument("--slo-ttft-ms", type=float, default=500)
    p.add_argument("--no-plot", action="store_true")
    args = p.parse_args()

    runs = load(args.results)
    if not runs:
        raise SystemExit(f"no benchmark JSON files in {args.results}/ (run infra/bench.sh first)")
    picks = write_markdown(runs, args.slo_ttft_ms, os.path.join(args.results, "summary.md"))
    with open(os.path.join(args.results, "summary.json"), "w") as f:
        json.dump({
            "slo_ttft_ms": args.slo_ttft_ms,
            "runs": runs,
            "best_under_slo": {r["label"]: b for r, b in picks},
        }, f, indent=2)
    print(open(os.path.join(args.results, "summary.md")).read())
    if not args.no_plot:
        plot(runs, args.slo_ttft_ms, os.path.join(args.results, "charts.png"))


if __name__ == "__main__":
    main()
