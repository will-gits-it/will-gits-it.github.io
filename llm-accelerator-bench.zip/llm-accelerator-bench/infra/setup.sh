#!/usr/bin/env bash
# One-time setup: APIs, GKE Autopilot cluster, bucket, Workload Identity, HF token secret.
# Usage:  source infra/env.sh && export HF_TOKEN=hf_xxx && bash infra/setup.sh
set -euo pipefail
: "${PROJECT_ID:?source infra/env.sh first}"
: "${HF_TOKEN:?export HF_TOKEN=hf_... (a write token from huggingface.co/settings/tokens)}"

echo "== enabling APIs"
gcloud services enable container.googleapis.com storage.googleapis.com

echo "== creating Autopilot cluster $CLUSTER in $REGION (about 5-10 min)"
if ! gcloud container clusters describe "$CLUSTER" --region "$REGION" >/dev/null 2>&1; then
  gcloud container clusters create-auto "$CLUSTER" --region "$REGION"
fi
gcloud container clusters get-credentials "$CLUSTER" --region "$REGION"

echo "== bucket gs://$BUCKET"
gcloud storage buckets describe "gs://$BUCKET" >/dev/null 2>&1 || \
  gcloud storage buckets create "gs://$BUCKET" --location "$REGION" --uniform-bucket-level-access

echo "== Workload Identity: let the 'trainer' Kubernetes SA write to the bucket (no keys)"
kubectl create serviceaccount trainer --dry-run=client -o yaml | kubectl apply -f -
PROJECT_NUMBER=$(gcloud projects describe "$PROJECT_ID" --format='value(projectNumber)')
gcloud storage buckets add-iam-policy-binding "gs://$BUCKET" \
  --member="principal://iam.googleapis.com/projects/${PROJECT_NUMBER}/locations/global/workloadIdentityPools/${PROJECT_ID}.svc.id.goog/subject/ns/default/sa/trainer" \
  --role="roles/storage.objectAdmin" >/dev/null

echo "== Hugging Face token secret"
kubectl create secret generic hf-token --from-literal=token="$HF_TOKEN" \
  --dry-run=client -o yaml | kubectl apply -f -

echo "done. next: bash infra/train.sh"
