#!/usr/bin/env bash
# Launch the fine-tuning Job on an L4 GPU (set ACCELERATOR=nvidia-tesla-t4 for a T4).
set -euo pipefail
cd "$(dirname "$0")/.."
: "${HF_REPO:?source infra/env.sh first}"
export ACCELERATOR="${ACCELERATOR:-nvidia-l4}"
# T4 has 16 GB and no bf16, so halve the batch and accumulate.
if [ "$ACCELERATOR" = "nvidia-tesla-t4" ]; then
  export EXTRA_TRAIN_ARGS="${EXTRA_TRAIN_ARGS:---batch-size 4 --grad-accum 2}"
else
  export EXTRA_TRAIN_ARGS="${EXTRA_TRAIN_ARGS:-}"
fi

kubectl create configmap finetune-code --from-file=finetune/ --dry-run=client -o yaml | kubectl apply -f -
kubectl delete job finetune --ignore-not-found
envsubst '$HF_REPO $GCS_URI $ACCELERATOR $EXTRA_TRAIN_ARGS' < k8s/train-job.yaml | kubectl apply -f -

echo "Job submitted. GPU node provisioning takes a few minutes. Follow along with:"
echo "  kubectl get pods -l app=finetune -w"
echo "  kubectl logs -f job/finetune"
