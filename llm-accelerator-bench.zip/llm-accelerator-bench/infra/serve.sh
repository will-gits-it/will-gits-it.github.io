#!/usr/bin/env bash
# Deploy the fine-tuned model behind vLLM on one GPU type.
# Usage: bash infra/serve.sh l4    or    bash infra/serve.sh t4
set -euo pipefail
cd "$(dirname "$0")/.."
: "${HF_REPO:?source infra/env.sh first}"
case "${1:-l4}" in
  l4) export GPU_NAME=l4 ACCELERATOR=nvidia-l4 ;;
  t4) export GPU_NAME=t4 ACCELERATOR=nvidia-tesla-t4 ;;
  *) echo "usage: serve.sh l4|t4"; exit 1 ;;
esac
export MODEL_REPO="$HF_REPO"
envsubst '$GPU_NAME $ACCELERATOR $MODEL_REPO' < k8s/vllm.yaml | kubectl apply -f -
echo "Waiting for vllm-$GPU_NAME to become ready (node provisioning + model download: ~5-10 min)..."
kubectl rollout status deployment/vllm-$GPU_NAME --timeout=20m
echo "Ready. Smoke test:"
echo "  kubectl port-forward svc/vllm-$GPU_NAME 8000:8000 &"
echo "  curl -s localhost:8000/v1/models"
