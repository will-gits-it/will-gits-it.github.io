#!/usr/bin/env bash
# Run the load test from inside the cluster (no port-forward overhead in the numbers)
# and save the results JSON to results/<gpu>.json.
# Usage: HOURLY_USD=0.80 bash infra/bench.sh l4
#   HOURLY_USD = what one replica costs per hour (GPU + its CPU/memory). See README for how to look it up.
set -euo pipefail
cd "$(dirname "$0")/.."
export GPU_NAME="${1:?usage: HOURLY_USD=x bash infra/bench.sh l4|t4}"
export HOURLY_USD="${HOURLY_USD:-0}"
export CONCURRENCY="${CONCURRENCY:-1,4,8,16,32,64}"
export REQUESTS="${REQUESTS:-64}"

kubectl create configmap bench-code --from-file=bench/ --dry-run=client -o yaml | kubectl apply -f -
kubectl delete job "bench-$GPU_NAME" --ignore-not-found
envsubst '$GPU_NAME $HOURLY_USD $CONCURRENCY $REQUESTS' < k8s/bench-job.yaml | kubectl apply -f -
kubectl wait --for=condition=complete "job/bench-$GPU_NAME" --timeout=30m
mkdir -p results
kubectl logs "job/bench-$GPU_NAME" | grep '^RESULT_JSON ' | sed 's/^RESULT_JSON //' > "results/$GPU_NAME.json"
kubectl logs "job/bench-$GPU_NAME" | grep -v '^RESULT_JSON '
echo "saved results/$GPU_NAME.json"
