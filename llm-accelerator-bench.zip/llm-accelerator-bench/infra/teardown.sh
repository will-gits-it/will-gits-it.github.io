#!/usr/bin/env bash
# Stop paying for GPUs. Scale-to-zero first (fast), then optionally delete everything.
# Usage: bash infra/teardown.sh          -> deletes GPU workloads (cluster stays, costs ~nothing idle on Autopilot)
#        bash infra/teardown.sh --all    -> also deletes the cluster (bucket is kept)
set -euo pipefail
: "${CLUSTER:?source infra/env.sh first}"
kubectl delete deployment vllm-l4 vllm-t4 --ignore-not-found
kubectl delete job finetune bench-l4 bench-t4 --ignore-not-found
if [ "${1:-}" = "--all" ]; then
  gcloud container clusters delete "$CLUSTER" --region "$REGION" --quiet
fi
echo "GPU workloads removed."
