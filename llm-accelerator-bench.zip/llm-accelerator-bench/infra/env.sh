# Edit these, then:  source infra/env.sh
export PROJECT_ID="your-gcp-project-id"
export REGION="us-central1"          # L4 and T4 are both available here
export CLUSTER="llm-bench"
export BUCKET="${PROJECT_ID}-llm-bench"
export HF_USER="your-hf-username"
export HF_REPO="${HF_USER}/qwen2.5-1.5b-sql"
export GCS_URI="gs://${BUCKET}/run1"

gcloud config set project "$PROJECT_ID" >/dev/null
